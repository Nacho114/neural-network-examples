import network
import numpy as np

# assume we are using 4 training samples


### Test setup
W1 = np.array([[1, 2],
               [3, 4],
               [5, 6]])

W2 = np.array([[1, 2, 3],
               [3, 4, 5]])

W = [W1, W2]

B1 = np.array([1, 2, 3]).reshape(3, 1)
B2 = np.array([1, 2]).reshape(2, 1)

B = [B1, B2]

# Testing with 2 samples

# Size of first layer
X = np.array([[1, 2],
              [5, 6]])

# Size of last layer
Y = np.array([[1, 2],
              [5, 6]])

### setup end

n_samples = X.shape[1]
net = network.Network([2, 3, 2], n_samples)
net.set_state(W, B, n_samples)


# To turn mini-batch into matrix use 'np.column_stack(X)'
