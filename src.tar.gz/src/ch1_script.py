import mnist_loader
import network
import matplotlib.pyplot as plt

training_data, validation_data, test_data = mnist_loader.load_data_wrapper()

net = network.Network([784, 30, 10])

def train_data(epochs, eta):
    return net.SGD_GET_DATA(training_data, epochs, 10, eta, test_data=test_data)


print 'running . . . '
#net.SGD(training_data, 30, 10, 0.1, test_data=test_data)

learning_rates = [0.01, 0.1, 0.5, 1, 3, 5]
#learning_rates = [0.1, 0.5, 1]
performance = []

for l in learning_rates:
    next_perf = train_data(30, l)
    performance.append(next_perf)
    print 'eta {0} completed.'.format(l)


for l, p in zip(learning_rates, performance):
    print 'eta = {0}, result = {1}'.format(l, p)

plt.plot(learning_rates, performance)
plt.plot(learning_rates, performance, 'ro')
plt.xlabel('eta (learning rate)')
plt.ylabel('accuracy')
plt.show()
